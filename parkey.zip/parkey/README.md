# Parkey

## Welcome

Parkey is a student-built password manager. We're learning by building a real, secure tool to help people manage their passwords effortlessly.

## Menu
[Requirements](#requirements)  
[Installation](#installation)  
[Usage guide](#usage-guide)  
[Contribution](#contribution)

## Requirements  
* Python 3.8 or higher  
    * Pillow
    * Crytography

## Installation


## Usage guide
### 1. Launch the application
### 2. Register a new account with a master password
### 3. Login with your accounts
### 4. View your stored passwords in the main menu
### 5. Add new passwords using the "Create" button

## Contribution
### GUI: Tran Le Nam Khanh
### Back-end: Tran Nhat Quang